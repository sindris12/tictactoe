
0.2.2 / 2014-10-01
==================
  
  * bump

0.2.1 / 2014-10-01
==================

  * Exit when there are no migrations to run

0.2.0 / 2014-10-01
==================

  * change the way config file is read, use `require` to load the file
    - This way allow `module.exports` in the config file

0.1.5 / 2014-10-01
==================

  * set mongoose dependency

0.1.4 / 2013-05-02
==================

  * fix create command
  * use mongo for migrations

0.1.0 / 2013-04-21
==================

  * fix create command
  * use environments
  * use mongoose to store migrations
  * add mongoose
